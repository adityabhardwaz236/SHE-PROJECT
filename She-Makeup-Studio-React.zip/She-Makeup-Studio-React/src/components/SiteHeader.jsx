"use client";

import { useState } from "react";
import { Link, useLocation } from "react-router-dom";

const links = [
  { href: "/", label: "Home" },
  { href: "/story", label: "Our Story" },
  { href: "/services", label: "Services" },
  { href: "/gallery", label: "Gallery" },
  { href: "/contact", label: "Contact" },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useLocation().pathname;

  return (
    <>
      <div className="announcement">
        <span>Private beauty studio · By appointment</span>
        <a href="/contact#booking">Bridal bookings open</a>
      </div>
      <header className="site-header">
        <Link className="brand" to="/" aria-label="She Makeup Studio home">
          <img src="/she-logo.jpeg" alt="She Makeup Studio logo" />
          <span><strong>She</strong><small>Makeup Studio</small></span>
        </Link>

        <button
          className="menu-toggle"
          type="button"
          aria-label="Toggle navigation"
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <span /><span />
        </button>

        <nav className={open ? "nav-links open" : "nav-links"} aria-label="Main navigation">
          {links.map((link) => (
            <Link
              className={pathname === link.href ? "active" : ""}
              to={link.href}
              key={link.href}
              onClick={() => setOpen(false)}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <Link className="header-cta" to="/contact#booking">Book an appointment <span>↗</span></Link>
      </header>
    </>
  );
}
