import { Link } from "react-router-dom";

const footerLinks = [
  { href: "/story", label: "Our Story" },
  { href: "/services", label: "Services" },
  { href: "/gallery", label: "Gallery" },
  { href: "/contact", label: "Contact" },
];

export default function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-brand">
        <img src="/she-logo.jpeg" alt="She Makeup Studio" />
        <div><strong>She</strong><span>Makeup Studio</span></div>
      </div>
      <div className="footer-message">
        <p>Beauty with intention.</p>
        <h2>Come as you are.<br /><em>Leave glowing.</em></h2>
      </div>
      <div className="footer-links">
        <div>
          <span>Explore</span>
          {footerLinks.map((link) => <Link to={link.href} key={link.href}>{link.label}</Link>)}
        </div>
        <div>
          <span>Appointments</span>
          <a href="/contact#booking">WhatsApp enquiry</a>
          <a href="/contact#visit">Visit the studio</a>
          <a href="/contact#faq">Booking questions</a>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 She Makeup Studio</span>
        <span>Private studio · By appointment</span>
        <a href="#top">Back to top ↑</a>
      </div>
    </footer>
  );
}
