# She Makeup Studio — Multi-page React Website

A premium responsive beauty-salon website built with React, Vite and React Router.

## Pages

- Home
- Our Story
- Services
- Gallery with category filters
- Contact, booking form and FAQs

## Run in VS Code

1. Extract the ZIP file.
2. Open the `She-Makeup-Studio-React` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

```bash
npm install
npm run dev
```

5. Open the localhost URL shown in the terminal, normally `http://localhost:5173`.

## Production build

```bash
npm run build
```

The production website will be created inside `dist`.

## Deploy on Vercel

1. Upload this folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Click **Deploy**.

`vercel.json` is included so every React Router page opens correctly after deployment.

## Deploy on Netlify

1. Import the GitHub repository into Netlify.
2. Build command: `npm run build`.
3. Publish directory: `dist`.
4. Click **Deploy**.

The required redirect configuration is already included.

## Add the real business information

Update `src/components/BookingForm.jsx` with the studio's WhatsApp number. Contact wording, service descriptions and page content are inside `src/pages`.
